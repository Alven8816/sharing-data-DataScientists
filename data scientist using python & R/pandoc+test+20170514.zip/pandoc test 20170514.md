
# Table of Contents
 <p><div class="lev1 toc-item"><a href="#数据科学探索（python-与-R-的比较）" data-toc-modified-id="数据科学探索（python-与-R-的比较）-1"><span class="toc-item-num">1&nbsp;&nbsp;</span>数据科学探索（python 与 R 的比较）</a></div><div class="lev2 toc-item"><a href="#数据读取" data-toc-modified-id="数据读取-11"><span class="toc-item-num">1.1&nbsp;&nbsp;</span>数据读取</a></div><div class="lev3 toc-item"><a href="#Python" data-toc-modified-id="Python-111"><span class="toc-item-num">1.1.1&nbsp;&nbsp;</span>Python</a></div><div class="lev3 toc-item"><a href="#R" data-toc-modified-id="R-112"><span class="toc-item-num">1.1.2&nbsp;&nbsp;</span>R</a></div><div class="lev2 toc-item"><a href="#数据描述" data-toc-modified-id="数据描述-12"><span class="toc-item-num">1.2&nbsp;&nbsp;</span>数据描述</a></div><div class="lev3 toc-item"><a href="#python" data-toc-modified-id="python-121"><span class="toc-item-num">1.2.1&nbsp;&nbsp;</span>python</a></div><div class="lev3 toc-item"><a href="#R" data-toc-modified-id="R-122"><span class="toc-item-num">1.2.2&nbsp;&nbsp;</span>R</a></div><div class="lev2 toc-item"><a href="#数据处理" data-toc-modified-id="数据处理-13"><span class="toc-item-num">1.3&nbsp;&nbsp;</span>数据处理</a></div><div class="lev3 toc-item"><a href="#python" data-toc-modified-id="python-131"><span class="toc-item-num">1.3.1&nbsp;&nbsp;</span>python</a></div><div class="lev3 toc-item"><a href="#R" data-toc-modified-id="R-132"><span class="toc-item-num">1.3.2&nbsp;&nbsp;</span>R</a></div><div class="lev2 toc-item"><a href="#建立预测模型" data-toc-modified-id="建立预测模型-14"><span class="toc-item-num">1.4&nbsp;&nbsp;</span>建立预测模型</a></div><div class="lev3 toc-item"><a href="#python" data-toc-modified-id="python-141"><span class="toc-item-num">1.4.1&nbsp;&nbsp;</span>python</a></div><div class="lev3 toc-item"><a href="#R" data-toc-modified-id="R-142"><span class="toc-item-num">1.4.2&nbsp;&nbsp;</span>R</a></div><div class="lev2 toc-item"><a href="#Logistic" data-toc-modified-id="Logistic-15"><span class="toc-item-num">1.5&nbsp;&nbsp;</span>Logistic</a></div><div class="lev3 toc-item"><a href="#python" data-toc-modified-id="python-151"><span class="toc-item-num">1.5.1&nbsp;&nbsp;</span>python</a></div><div class="lev3 toc-item"><a href="#R" data-toc-modified-id="R-152"><span class="toc-item-num">1.5.2&nbsp;&nbsp;</span>R</a></div><div class="lev2 toc-item"><a href="#决策树" data-toc-modified-id="决策树-16"><span class="toc-item-num">1.6&nbsp;&nbsp;</span>决策树</a></div><div class="lev3 toc-item"><a href="#python" data-toc-modified-id="python-161"><span class="toc-item-num">1.6.1&nbsp;&nbsp;</span>python</a></div><div class="lev3 toc-item"><a href="#R" data-toc-modified-id="R-162"><span class="toc-item-num">1.6.2&nbsp;&nbsp;</span>R</a></div><div class="lev2 toc-item"><a href="#随机森林" data-toc-modified-id="随机森林-17"><span class="toc-item-num">1.7&nbsp;&nbsp;</span>随机森林</a></div><div class="lev3 toc-item"><a href="#python" data-toc-modified-id="python-171"><span class="toc-item-num">1.7.1&nbsp;&nbsp;</span>python</a></div><div class="lev3 toc-item"><a href="#R" data-toc-modified-id="R-172"><span class="toc-item-num">1.7.2&nbsp;&nbsp;</span>R</a></div>

# 数据科学探索（python 与 R 的比较）

    分别应用python和R 2种工具对某真实信贷数据进行分析，通过数据的读取、清洗、探索、模型构建等，比较2种方法在机器学习数据科学上的实现。

## 数据读取

    数据来源于[Analytics Vidhya](https://datahack.analyticsvidhya.com/contest/practice-problem-loan-prediction-iii/) 房屋信贷公司根据贷款人的年龄、性别、婚否、家庭成员、收入、信用贷款等相关信息，预测是否予以贷款。

### Python 


```R
%matplotlib inline 
```


```R
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
```


```R
df = pd.read_csv("C:/Users/HP/Desktop/train.csv")
```


```R
df.head()
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Loan_ID</th>
      <th>Gender</th>
      <th>Married</th>
      <th>Dependents</th>
      <th>Education</th>
      <th>Self_Employed</th>
      <th>ApplicantIncome</th>
      <th>CoapplicantIncome</th>
      <th>LoanAmount</th>
      <th>Loan_Amount_Term</th>
      <th>Credit_History</th>
      <th>Property_Area</th>
      <th>Loan_Status</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>LP001002</td>
      <td>Male</td>
      <td>No</td>
      <td>0</td>
      <td>Graduate</td>
      <td>No</td>
      <td>5849</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>Urban</td>
      <td>Y</td>
    </tr>
    <tr>
      <th>1</th>
      <td>LP001003</td>
      <td>Male</td>
      <td>Yes</td>
      <td>1</td>
      <td>Graduate</td>
      <td>No</td>
      <td>4583</td>
      <td>1508.0</td>
      <td>128.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>Rural</td>
      <td>N</td>
    </tr>
    <tr>
      <th>2</th>
      <td>LP001005</td>
      <td>Male</td>
      <td>Yes</td>
      <td>0</td>
      <td>Graduate</td>
      <td>Yes</td>
      <td>3000</td>
      <td>0.0</td>
      <td>66.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>Urban</td>
      <td>Y</td>
    </tr>
    <tr>
      <th>3</th>
      <td>LP001006</td>
      <td>Male</td>
      <td>Yes</td>
      <td>0</td>
      <td>Not Graduate</td>
      <td>No</td>
      <td>2583</td>
      <td>2358.0</td>
      <td>120.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>Urban</td>
      <td>Y</td>
    </tr>
    <tr>
      <th>4</th>
      <td>LP001008</td>
      <td>Male</td>
      <td>No</td>
      <td>0</td>
      <td>Graduate</td>
      <td>No</td>
      <td>6000</td>
      <td>0.0</td>
      <td>141.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>Urban</td>
      <td>Y</td>
    </tr>
  </tbody>
</table>
</div>




```R
df.describe()
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ApplicantIncome</th>
      <th>CoapplicantIncome</th>
      <th>LoanAmount</th>
      <th>Loan_Amount_Term</th>
      <th>Credit_History</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>614.000000</td>
      <td>614.000000</td>
      <td>592.000000</td>
      <td>600.00000</td>
      <td>564.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>5403.459283</td>
      <td>1621.245798</td>
      <td>146.412162</td>
      <td>342.00000</td>
      <td>0.842199</td>
    </tr>
    <tr>
      <th>std</th>
      <td>6109.041673</td>
      <td>2926.248369</td>
      <td>85.587325</td>
      <td>65.12041</td>
      <td>0.364878</td>
    </tr>
    <tr>
      <th>min</th>
      <td>150.000000</td>
      <td>0.000000</td>
      <td>9.000000</td>
      <td>12.00000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>2877.500000</td>
      <td>0.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>3812.500000</td>
      <td>1188.500000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>5795.000000</td>
      <td>2297.250000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>max</th>
      <td>81000.000000</td>
      <td>41667.000000</td>
      <td>700.000000</td>
      <td>480.00000</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>



### R


```R
 #设置mirror
local(
{
r <- getOption("repos")
r["CRAN"] <- "http://mirrors.xmu.edu.cn/CRAN/"
options(repos=r)
})

```


```R
install.packages("ggplot2")
install.packages("dplyr")
install.packages("Hmisc")
install.packages("psych")
```

    
      有二进制版本（将被安装），但源代码版本是后来的:
            binary source
    ggplot2  2.1.0  2.2.1
    
    

    also installing the dependencies 'colorspace', 'RColorBrewer', 'dichromat', 'munsell', 'labeling', 'gtable', 'plyr', 'reshape2', 'scales'
    
    

    package 'colorspace' successfully unpacked and MD5 sums checked
    package 'RColorBrewer' successfully unpacked and MD5 sums checked
    package 'dichromat' successfully unpacked and MD5 sums checked
    package 'munsell' successfully unpacked and MD5 sums checked
    package 'labeling' successfully unpacked and MD5 sums checked
    package 'gtable' successfully unpacked and MD5 sums checked
    package 'plyr' successfully unpacked and MD5 sums checked
    package 'reshape2' successfully unpacked and MD5 sums checked
    package 'scales' successfully unpacked and MD5 sums checked
    package 'ggplot2' successfully unpacked and MD5 sums checked
    
    The downloaded binary packages are in
    	C:\Users\HP\AppData\Local\Temp\RtmpgPWYPJ\downloaded_packages
    
      有二进制版本（将被安装），但源代码版本是后来的:
          binary source
    dplyr  0.4.3  0.5.0
    
    package 'dplyr' successfully unpacked and MD5 sums checked
    
    The downloaded binary packages are in
    	C:\Users\HP\AppData\Local\Temp\RtmpgPWYPJ\downloaded_packages
    


```R
library(ggplot2)
library(dplyr)
library(psych)
library(Hmisc)
```

    
    Attaching package: 'dplyr'
    
    The following objects are masked from 'package:Hmisc':
    
        combine, src, summarize
    
    The following objects are masked from 'package:stats':
    
        filter, lag
    
    The following objects are masked from 'package:base':
    
        intersect, setdiff, setequal, union
    
    
    Attaching package: 'psych'
    
    The following object is masked from 'package:Hmisc':
    
        describe
    
    The following objects are masked from 'package:ggplot2':
    
        %+%, alpha
    
    


```R
train <- read.csv("C:/Users/HP/Desktop/train.csv",header = TRUE)
```


```R
head(train)
```




<table>
<thead><tr><th></th><th scope=col>Loan_ID</th><th scope=col>Gender</th><th scope=col>Married</th><th scope=col>Dependents</th><th scope=col>Education</th><th scope=col>Self_Employed</th><th scope=col>ApplicantIncome</th><th scope=col>CoapplicantIncome</th><th scope=col>LoanAmount</th><th scope=col>Loan_Amount_Term</th><th scope=col>Credit_History</th><th scope=col>Property_Area</th><th scope=col>Loan_Status</th></tr></thead>
<tbody>
	<tr><th scope=row>1</th><td>LP001002</td><td>Male</td><td>No</td><td>0</td><td>Graduate</td><td>No</td><td>5849</td><td>0</td><td>NA</td><td>360</td><td>1</td><td>Urban</td><td>Y</td></tr>
	<tr><th scope=row>2</th><td>LP001003</td><td>Male</td><td>Yes</td><td>1</td><td>Graduate</td><td>No</td><td>4583</td><td>1508</td><td>128</td><td>360</td><td>1</td><td>Rural</td><td>N</td></tr>
	<tr><th scope=row>3</th><td>LP001005</td><td>Male</td><td>Yes</td><td>0</td><td>Graduate</td><td>Yes</td><td>3000</td><td>0</td><td>66</td><td>360</td><td>1</td><td>Urban</td><td>Y</td></tr>
	<tr><th scope=row>4</th><td>LP001006</td><td>Male</td><td>Yes</td><td>0</td><td>Not Graduate</td><td>No</td><td>2583</td><td>2358</td><td>120</td><td>360</td><td>1</td><td>Urban</td><td>Y</td></tr>
	<tr><th scope=row>5</th><td>LP001008</td><td>Male</td><td>No</td><td>0</td><td>Graduate</td><td>No</td><td>6000</td><td>0</td><td>141</td><td>360</td><td>1</td><td>Urban</td><td>Y</td></tr>
	<tr><th scope=row>6</th><td>LP001011</td><td>Male</td><td>Yes</td><td>2</td><td>Graduate</td><td>Yes</td><td>5417</td><td>4196</td><td>267</td><td>360</td><td>1</td><td>Urban</td><td>Y</td></tr>
</tbody>
</table>





```R
describe(train)
```




<table>
<thead><tr><th></th><th scope=col>vars</th><th scope=col>n</th><th scope=col>mean</th><th scope=col>sd</th><th scope=col>median</th><th scope=col>trimmed</th><th scope=col>mad</th><th scope=col>min</th><th scope=col>max</th><th scope=col>range</th><th scope=col>skew</th><th scope=col>kurtosis</th><th scope=col>se</th></tr></thead>
<tbody>
	<tr><th scope=row>Loan_ID*</th><td>1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13</td></tr>
	<tr><th scope=row>Gender*</th><td>614, 614, 614, 614, 614, 614, 614, 614, 592, 600, 564, 614, 614</td></tr>
	<tr><th scope=row>Married*</th><td>307.5000000, 2.7752443, 2.6433225, 2.7198697, 1.2182410, 2.0814332, 5403.4592834, 1621.2457980, 146.4121622, 342.0000000, 0.8421986, 2.0374593, 1.6872964</td></tr>
	<tr><th scope=row>Dependents*</th><td>177.3908115, 0.4657673, 0.4895109, 1.0390559, 0.4133887, 0.4234719, 6109.0416734, 2926.2483692, 85.5873252, 65.1204099, 0.3648783, 0.7874820, 0.4639727</td></tr>
	<tr><th scope=row>Education*</th><td>307.5, 3.0, 3.0, 2.0, 1.0, 2.0, 3812.5, 1188.5, 128.0, 360.0, 1.0, 2.0, 2.0</td></tr>
	<tr><th scope=row>Self_Employed*</th><td>307.5000000, 2.8699187, 2.6849593, 2.5772358, 1.1483740, 2.0426829, 4292.0589431, 1154.8473984, 133.1434599, 358.3750000, 0.9269912, 2.0467480, 1.7337398</td></tr>
	<tr><th scope=row>ApplicantIncome</th><td>227.5791, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 1822.8567, 1762.0701, 47.4432, 0.0000, 0.0000, 1.4826, 0.0000</td></tr>
	<tr><th scope=row>CoapplicantIncome</th><td>1, 1, 1, 1, 1, 1, 150, 0, 9, 12, 0, 1, 1</td></tr>
	<tr><th scope=row>LoanAmount</th><td>614, 3, 3, 5, 2, 3, 81000, 41667, 700, 480, 1, 3, 2</td></tr>
	<tr><th scope=row>Loan_Amount_Term</th><td>613, 2, 2, 4, 1, 2, 80850, 41667, 691, 468, 1, 2, 1</td></tr>
	<tr><th scope=row>Credit_History</th><td>0.00000000, -1.92394251, -0.72152527, 0.89096131, 1.36094707, 0.48926005, 6.50759579, 7.45496739, 2.66399829, -2.35061518, -1.87236034, -0.06587306, -0.80604475</td></tr>
	<tr><th scope=row>Property_Area*</th><td>-1.2058648, 2.9113713, -1.1618638, -0.3811864, -0.1480562, 2.1742694, 59.8338687, 83.9723852, 10.2588649, 6.5760077, 1.5084172, -1.3874327, -1.3524867</td></tr>
	<tr><th scope=row>Loan_Status*</th><td>7.15891053, 0.01879684, 0.01975505, 0.04193288, 0.01668301, 0.01708993, 246.54085748, 118.09377325, 3.51761740, 2.65852960, 0.01536415, 0.03178019, 0.01872441</td></tr>
</tbody>
</table>




## 数据描述

    主要包括对计量资料和分类变量的分布进行绘图描述。python主要运用到matplotlib库，R主要运用到ggplot2包。

### python


```R
#查看申请人地域分布
df['Property_Area'].value_counts()
```


```R
#查看申请人收入分布情况
df['ApplicantIncome'].hist(bins=50)
```


```R
#按教育情况分类，查看收入情况
df.boxplot(column='ApplicantIncome', by = 'Education')
```


    Error in grepl("\n", lines, fixed = TRUE): '<8c>'多字节字符串有错
    



```R
#查看申请人信用历史分布并绘图
temp1 = df['Credit_History'].value_counts(ascending=True)
temp2 = df.pivot_table(values='Loan_Status', index=['Credit_History'],aggfunc=lambda x: x.map({'Y':1,"N":0}).mean())
print 'Frequency Table for Credit History:'
print temp1

print '\nProbility of getting loan for each Credit History class:'
print temp2
```


    Error in grepl("\n", lines, fixed = TRUE): '<98>'多字节字符串有错
    



```R
import matplotlib.pyplot as plt
fig = plt.figure(figsize=(8,4))
ax1 = fig.add_subplot(121)
ax1.set_xlabel('Credit_History')
ax1.set_ylabel('Count of Applicants')
ax1.set_title('Applicants by Credit_History')
temp1.plot(kind= 'bar')

ax2 = fig.add_subplot(122)
temp2.plot(kind = 'bar')
ax2.set_xlabel('credit_history')
ax2.set_ylabel('probability of getting loan')
ax2.set_title('probability of getting loan by credit history')

```


    Error in parse(text = x, srcfile = src): <text>:1:8: 意外的符号
    1: import matplotlib.pyplot
               ^
    



```R
temp3 = pd.crosstab(df['Credit_History'], df['Loan_Status'])
temp3.plot(kind='bar', stacked=True, color=['red','blue'],grid=False)
```


    Error in parse(text = x, srcfile = src): <text>:2:44: 意外的'['
    1: temp3 = pd.crosstab(df['Credit_History'], df['Loan_Status'])
    2: temp3.plot(kind='bar', stacked=True, color=[
                                                  ^
    


### R


```R
#申请人地域分布
table(train$Property_Area)
```


```R
#申请人收入分布情况
ggplot(data=train, aes(x=ApplicantIncome)) + geom_histogram(bins = 50, fill = "blue")
```


```R

```


```R
ggplot(data=train, aes(x=Education, y=ApplicantIncome)) + geom_boxplot()
```




```R

```

## 数据处理

    主要包括以下方面：
1. 缺失值处理
2. 极值处理

### python


```R
# 检测缺失值
df.apply(lambda x: sum(x.isnull()), axis = 0)
```




    Loan_ID               0
    Gender               13
    Married               3
    Dependents           15
    Education             0
    Self_Employed        32
    ApplicantIncome       0
    CoapplicantIncome     0
    LoanAmount           22
    Loan_Amount_Term     14
    Credit_History       50
    Property_Area         0
    Loan_Status           0
    dtype: int64




```R
#计量资料用均值、计数资料用众数填补
df['LoanAmount'].fillna(df['LoanAmount'].mean(),inplace=True)
```


```R
#查看分布
df['Self_Employed'].value_counts()
df['Credit_History'].value_counts()
df['Gender'].value_counts() 
df['Loan_Amount_Term'].value_counts()
```




    1    500
    2     82
    0     32
    Name: Self_Employed, dtype: int64




```R

df['Loan_Amount_Term'].fillna(360.0,inplace=True)
```


```R
df['Gender'].fillna(2,inplace=True)
```


```R

df['Credit_History'].fillna(1.0,inplace=True)
```


```R
table = df.pivot_table(values='LoanAmount',index='Self_Employed',columns='Education',aggfunc=np.median)
print(table)
```


```R
df['Self_Employed'].fillna('NO',inplace=True)
```


```R
#最后查看填补结果
df.apply(lambda x: sum(x.isnull()), axis = 0)
```




    Loan_ID              0
    Gender               0
    Married              0
    Dependents           0
    Education            0
    Self_Employed        0
    ApplicantIncome      0
    CoapplicantIncome    0
    LoanAmount           0
    Loan_Amount_Term     0
    Credit_History       0
    Property_Area        0
    Loan_Status          0
    dtype: int64




```R
#数据变换
#转换为收入log值
df['LoanAmount_log'] = np.log(df['LoanAmount'])
df['LoanAmount_log'].hist(bins=20)
```




    <matplotlib.axes._subplots.AxesSubplot at 0xc6c0e80>




![png](output_45_1.png)



```R
df['TotalIncome'] = df['ApplicantIncome'] + df['CoapplicantIncome']
df['TotalIncome_log'] = np.log(df['TotalIncome'])
df['LoanAmount_log'].hist(bins=20) 
```




    <matplotlib.axes._subplots.AxesSubplot at 0xd885588>




![png](output_46_1.png)


### R


```R
#查看缺失情况
pMiss <- function(x) {
    sum(is.na(x))/length(x)*100 }
apply(train, 2, pMiss)
```

          Loan_ID            Gender           Married        Dependents         Education 
         0.000000          0.000000          0.000000          0.000000          0.000000 
    Self_Employed   ApplicantIncome CoapplicantIncome        LoanAmount  Loan_Amount_Term 
         0.000000          0.000000          0.000000          3.583062          2.280130 
   Credit_History     Property_Area       Loan_Status 
         8.143322          0.000000          0.000000 


```R
library(Hmisc)
train$LoanAmount <- impute(train$LoanAmount, mean)
```

    Loading required package: lattice
    Loading required package: survival
    Loading required package: Formula
    Loading required package: ggplot2
    
    Attaching package: 'Hmisc'
    
    The following objects are masked from 'package:base':
    
        format.pval, round.POSIXt, trunc.POSIXt, units
    
    Warning message:
    In is.na(x): is.na()不适用于类别为'NULL'的非串列或非矢量


```R
train$Loan_Amount_Term <- impute(train$Loan_Amount_Term, 360.0)
train$Credit_History <- impute(train$Credit_History, 1.0)
```


```R
#数据变换
#转换为收入log值
library(dplyr)
train = mutate(train, LoanAmount_log = log(LoanAmount), TotalIncome = ApplicantIncome + CoapplicantIncome,
TotalIncome_log =log(TotalIncome))
#apply(train, 2, pMiss)
```

          Loan_ID            Gender           Married        Dependents         Education 
                0                 0                 0                 0                 0 
    Self_Employed   ApplicantIncome CoapplicantIncome        LoanAmount  Loan_Amount_Term 
                0                 0                 0                 0                 0 
   Credit_History     Property_Area       Loan_Status    LoanAmount_log       TotalIncome 
                0                 0                 0                 0                 0 
  TotalIncome_log 
                0 

## 建立预测模型

### python


```R
#转变所有的分类变量为数值变量
from sklearn.preprocessing import LabelEncoder
var_mod = ['Gender','Married','Dependents','Education','Self_Employed','Property_Area','Loan_Status']
le = LabelEncoder()
for i in var_mod:
    df[i] = le.fit_transform(df[i])
df.dtypes
```




    Loan_ID               object
    Gender                 int64
    Married                int64
    Dependents             int64
    Education              int64
    Self_Employed          int64
    ApplicantIncome        int64
    CoapplicantIncome    float64
    LoanAmount           float64
    Loan_Amount_Term     float64
    Credit_History       float64
    Property_Area          int64
    Loan_Status            int64
    dtype: object




```R
# import models from scikit learn module
from sklearn.linear_model import LogisticRegression
from sklearn.cross_validation import KFold #for k-fold cross validation
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier, export_graphviz
from sklearn import metrics

# Generic function for making a classification model and accessing performance
def classification_model(model, data, predictors, outcome):
    #fit the model
    model.fit(data[predictors], data[outcome])
    #make predictions on training set:
    predictions = model.predict(data[predictors])
    
    #print accuracy
    accuracy = metrics.accuracy_score(predictions, data[outcome])
    print "Accuracy : %s" % "{0:.3%}".format(accuracy)
    
    #perform k-ford cross-validation with 5 folds
    kf = KFold(data.shape[0], n_folds = 5)
    error = []
    for train, test in kf:
        #filter training data
        train_predictors = (data[predictors].iloc[train,:])
        
        #the target we're using to train the algorithm
        train_target = data[outcome].iloc[train]
        #训练模型使用predictors 和target
        model.fit(train_predictors, train_target)
        #对交叉验证记录error
        error.append(model.score(data[predictors].iloc[test,:],data[outcome].iloc[test]))
        
        print "Cross-Validation Score : %s" % "{0:.3%}".format(np.mean(error))
        
        #fit the model again so that it can be refered outside the function:
        model.fit(data[predictors],data[outcome])
        
        
```

### R


```R
library(rpart)
library(e1071)
library(rpart.plot)
library(caret)
library(Metrics)
```


```R
test <- read.csv("C:/Users/HP/Desktop/test.csv",header = TRUE)

```

## Logistic

### python


```R
outcome_var = 'Loan_Status'
model = LogisticRegression()
predictor_var = ['Credit_History']
classification_model(model, df,predictor_var,outcome_var)
```

    Accuracy : 80.945%
    Cross-Validation Score : 80.946%
    

### R


```R
#设置控制参数
fitControl <- trainControl(method = "cv", number = 5)

#拟合模型
logistic_model <- train(Loan_Status ~., data= train, method = "glmnet", trControl = fitControl, family="binormal")
print(logistic_model)
```


```R
#选择最优模型
logistic_model <- train(Loan_Status ~., data= train, method = "glmnet", trControl = fitControl, family="binormal")
#模型预测
logistic_predict <- predict(logistic_model, newdata= test,type = "vector")
```


```R
#模型评价
confusionMatrix(train$Loan_Status, logistic_model)
```

## 决策树

### python


```R
model = DecisionTreeClassifier()
predictor_var = ['Credit_History','Gender','Married','Education']
classification_model(model, df,predictor_var,outcome_var)
```

    Accuracy : 80.945%
    Cross-Validation Score : 80.946%
    

### R


```R
library(rpart)
library(e1071)
library(rpart.plot)
library(caret)
library(Metrics)
```


```R
#设置控制参数
fitControl <- trainControl(method = "cv", number = 5)
cartGrid <- expand.grid(.cp=(1:50)*0.01)
#拟合模型
tree_model <- train(Loan_Status ~., data= train, method = "rpart", trControl = fitControl, tuneGrid = cartGrid)
print(tree_model)
```


```R
#选择最优决策树模型
main_tree <- rpart(Loan_Status ~., data= train, control = rpart.control(cp=0.01))
```


```R
#绘制决策树
prp(main_tree)
```


```R
#模型预测
pre_score <- predict(main_tree,type = "vector")
#模型评价
confusionMatrix(train$Loan_Status, pre_score)
```

## 随机森林

### python


```R
#随机森林
model = RandomForestClassifier(n_estimators=100)
predictor_var = ['Gender', 'Married', 'Dependents', 'Education',
       'Self_Employed', 'Loan_Amount_Term', 'Credit_History', 'Property_Area']
classification_model(model, df,predictor_var,outcome_var)

```

    Accuracy : 87.296%
    Cross-Validation Score : 75.572%
    


```R
#Create a series with feature importances:
featimp = pd.Series(model.feature_importances_, index=predictor_var).sort_values(ascending=False)
print featimp
```

    Credit_History      0.416379
    Dependents          0.151294
    Loan_Amount_Term    0.104705
    Property_Area       0.104284
    Self_Employed       0.076248
    Gender              0.057447
    Education           0.045272
    Married             0.044371
    dtype: float64
    


```R
model = RandomForestClassifier(n_estimators=25, min_samples_split=25, max_depth=7, max_features=1)
predictor_var = ['Credit_History','Dependents','Property_Area']
classification_model(model, df,predictor_var,outcome_var)
```

    Accuracy : 80.945%
    Cross-Validation Score : 80.458%
    

### R


```R
library(randomForest)
```


```R
#设置参数
control <- trainControl(method = "cv", number = 5)
#随机森林
rf_model <- train(Loan_Status ~., data= train, method = "parRF",
                 trControl= control, prox = TRUE, allowParallel= TRUE)
print(rf_model)

```


```R
#选择最优决策树
forest_model <- randomForest(Loan_Status ~., data= train,
                            mtry = 15, ntree = 1000)
print(forest_model)
```


```R
#查看变量重要性排序
varImplot(forest_model)
```


```R
#模型预测
main_predict <- predict(forest_model, newdata= test,type = "vector")

```


```R
#模型评价
confusionMatrix(train$Loan_Status, main_predict)
```
