library("testthat")
library("qdap")


test_check("qdap")